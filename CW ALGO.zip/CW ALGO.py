#Name:- M.A.Oshadha Imantha
#UoW No:-W1830150
#IIT No:-20200488
#”I confirm that I understand what plagiarism is and have read and understood the section on Assessment Offences in the Essential Information for Students. The work that I have submitted is entirely my own. Any work from other authors is duly  referenced and acknowledged.”





import queue
import os

FOLDER_NAME = "cw1/"
START = "S"
END = "F"

def printMaze(maze, start_x, start_y, path="."):
    
    i = start_x
    j = start_y
    pos = set()
    for move in path:
        if move == "L":
            i -= 1

        elif move == "R":
            i += 1

        elif move == "U":
            j -= 1

        elif move == "D":
            j += 1
        pos.add((j, i))
    
    for j, row in enumerate(maze):
        for i, col in enumerate(row):
            if (j, i) in pos:
                print("+ ", end="")
            else:
                print(col + " ", end="")
        print()
 

def findStart(maze):
    for j, row in enumerate(maze):
        for i,ele in enumerate(row):
            if(maze[j][i] == START):
                return (i,j)


def valid(maze, start_x, start_y, moves):
    

    i = start_x
    j = start_y
    for move in moves:
        if move == "L":
            i -= 1

        elif move == "R":
            i += 1

        elif move == "U":
            j -= 1

        elif move == "D":
            j += 1

        if not(0 <= i < len(maze[0]) and 0 <= j < len(maze)):
            return False
        elif (maze[j][i] == "0"):
            return False

    return True


def findEnd(maze, start_x, start_y, moves):
    i = start_x
    j = start_y
    for move in moves:
        if move == "L":
            i -= 1

        elif move == "R":
            i += 1

        elif move == "U":
            j -= 1

        elif move == "D":
            j += 1

    if maze[j][i] == END:
        print("Found: " + moves)
        printMaze(maze, start_x, start_y, moves)
        return True

    return False


def process_maze(maze):
    print("Processing...")
    nums = queue.Queue()
    nums.put("")
    add = ""
    start_x, start_y = findStart(maze)

    while not findEnd(maze,start_x, start_y, add): 
        # print(".", end="")
        add = nums.get()
        #print(add)
        for j in ["L", "R", "U", "D"]:
            put = add + j
            if valid(maze, start_x, start_y, put):
                nums.put(put)
    print()



def main():
    # read from all files
    dir_list = os.listdir (FOLDER_NAME)

    for file in dir_list:
        print("File : " + file)
        with open(FOLDER_NAME+file, "r") as f:   
            maze = []
            for line in f:
                maze.append(list(line.replace("\n", "")))
            process_maze(maze)



if __name__ == "__main__":
    main()



             